import time
import numpy
import numpy as np
from matplotlib import pyplot as plt
from numpy import linalg
from sklearn.datasets import make_classification, load_digits
from sklearn.metrics import confusion_matrix
from sklearn.model_selection import train_test_split


def fit(X, Y, N):
    labels = set(Y.flatten())
    cls = list(labels)
    nb_cls = len(cls)
    weight_vectors = np.zeros((nb_cls, X.shape[1]))

    for k in range(1, N + 1):
        for i in range(Y.shape[0]):
            x = X[i, :]
            y = Y[i]
            for j in range(Y.shape[0]):
                y_pred = np.argmax([np.dot(x, weight_vectors[i, :]) for i in range(nb_cls)])
                if y != y_pred:
                    weight_vectors[cls.index(y), :] = weight_vectors[cls.index(y), :] + x
                    weight_vectors[cls.index(y_pred), :] = weight_vectors[cls.index(y_pred), :] - x
    return weight_vectors


def predict_example(x_test, weight_vectors):
    return np.argmax([np.dot(x_test, weight_vectors[i, :]) for i in range(weight_vectors.shape[0])])


def predict(X_test, weight_vectors):
    y_pred = np.zeros(X_test.shape[0])
    for i in range(X_test.shape[0]):
        y_pred[i] = predict_example(X_test[i], weight_vectors)
    return y_pred


def score(test, pred):
    nb_ok = len(numpy.argwhere(test == pred)[:, 0])
    return nb_ok / len(test)


def cm_norm(test, pred):
    c_m = confusion_matrix(test, pred, normalize='true')
    np.fill_diagonal(c_m, 0)
    norm = linalg.norm(c_m, ord=None, axis=None, keepdims=False)
    return norm


# evaluer perceptron sur data avec p_iterations et nb_hold_out fois
# retourner listes de N_mean scores, score CMDwD, temps d'apprentissage et weight_vectors
def evaluate_perceptron(data, p_iterations, nb_hold_out):
    times_list = []
    tbc_score = []
    cmd_score = []
    weight_vectors = []
    for i in range(nb_hold_out):
        X_train, X_test, y_train, y_test = train_test_split(data[0], data[1], test_size=0.30)

        start_time = time.time()
        w_v = fit(X_train, y_train, p_iterations)
        end_time = time.time()

        y_pred = predict(X_test, w_v)

        taux_clasif_ok = score(y_test, y_pred)

        times_list.append(end_time - start_time)
        tbc_score.append(taux_clasif_ok)
        cmd_score.append(cm_norm(y_test, y_pred))
        weight_vectors.append(w_v)
    return tbc_score, cmd_score, times_list, weight_vectors


def plot_points_hyperplanes(X1, weight_vectors):
    fig = plt.figure()
    ax = plt.axes(projection='3d')
    ax.scatter(X1[:, 0], X1[:, 1], X1[:, 2], c=Y1, cmap='viridis', edgecolor='none')
    ax.set_title('(S1) 5 cls, 100 ex, 3 dim, conf 0.1')

    x = X1[:, 0]
    y = X1[:, 1]

    for i in range(weight_vectors.shape[1]):
        w1 = weight_vectors[i][0]
        w2 = weight_vectors[i][1]
        w3 = weight_vectors[i][2]
        w4 = weight_vectors[i][3]

        Xs, Ys = np.meshgrid(x, y)
        Zs = (w4 - w1 * Xs - w2 * Ys) / w3
        ax.plot_surface(Xs, Ys, Zs, alpha=0.2)
    return fig


if __name__ == "__main__":
    X1, Y1 = make_classification(
        n_samples=100,
        n_classes=5,
        n_features=3,
        n_informative=3,
        n_redundant=0,
        n_clusters_per_class=1,
        flip_y=0.1
    )

    X2, Y2 = make_classification(
        n_samples=100,
        n_classes=5,
        n_features=3,
        n_informative=3,
        n_redundant=0,
        n_clusters_per_class=1,
        flip_y=0
    )

    X1 = np.c_[X1, np.ones(X1.shape[0])]
    X2 = np.c_[X2, np.ones(X2.shape[0])]

    S1 = [X1, Y1]
    S2 = [X2, Y2]
    k = 1
    vectors_S = []

    for S in [S1, S2]:
        scores, scores_cmd, times, vectors = evaluate_perceptron(S, 5, 10)

        print('Score S' + str(k), sum(scores) / len(scores))
        print('Temps d\'apprentissage S' + str(k), sum(times) / len(times))
        print('CMNwD S' + str(k), sum(scores_cmd) / len(scores_cmd))
        vectors_S.append(vectors)
        k += 1

    # plot hyperplanes for S1
    vectors_X1 = vectors_S[0]
    vector = vectors_X1[0]
    fig2 = plot_points_hyperplanes(X1, vector)

    # variation by nb_examples
    scores = []
    cm_scores = []
    for i in range(100, 1001, 100):
        scores_100 = []
        cm_scores_100 = []
        for j in range(10):
            X3, Y3 = make_classification(
                n_samples=i,
                n_classes=5,
                n_features=10,
                n_informative=10,
                n_redundant=0,
                n_clusters_per_class=1,
                flip_y=0.1
            )
            X3 = np.c_[X3, np.ones(X3.shape[0])]
            S3 = [X3, Y3]
            scores_100, cm_scores_100, times, w_vectors = evaluate_perceptron(S3, 1, 1)
        scores.append(sum(scores_100) / len(scores_100))
        cm_scores.append(sum(cm_scores_100) / len(cm_scores_100))

    f1, ax5 = plt.subplots()
    ax5.plot([i for i in range(100, 1001, 100)], scores, label='Score taux b. classif')
    ax5.plot([i for i in range(100, 1001, 100)], cm_scores, label='CMDwD')
    ax5.set_xlabel('Nombre d\'exemples')
    ax5.set_ylabel('Score')
    ax5.set_title('Perceptron - S4 score - nombre d\'exemples')
    plt.legend()

    digitsData = load_digits()
    X_digits = digitsData.data
    y_digits = digitsData.target

    scores_digits = []
    cm_scores_digits = []
    for i in range(100, 1001, 100):
        X_digits = np.c_[X_digits, np.ones(X_digits.shape[0])]
        S_digit = [X_digits, y_digits]
        scores_100, cm_scores_100, times, w_vectors = evaluate_perceptron(S_digit, 1, 1)
        scores_digits.append(sum(scores_100) / len(scores_100))
        cm_scores_digits.append(sum(cm_scores_100) / len(cm_scores_100))

    f2, ax6 = plt.subplots()
    ax6.plot([i for i in range(100, 1001, 100)], scores_digits, label='Score taux b. classif')
    ax6.plot([i for i in range(100, 1001, 100)], cm_scores_digits, label='CMDwD')
    ax6.set_xlabel('Nombre d\'exemples')
    ax6.set_ylabel('Score')
    ax6.set_title('Perceptron - Score digits')
    plt.legend()


    plt.show()
