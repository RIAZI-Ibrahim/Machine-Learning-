import math
from collections import Counter

import numpy
from matplotlib import pyplot as plt
from numpy import linalg
from sklearn.datasets import make_classification
from sklearn.decomposition import PCA
import numpy as np
from sklearn.metrics import confusion_matrix
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier
import scipy.stats as st

fig = plt.figure()
# exo 1.1.a.
X1, Y1 = make_classification(
    n_samples=100,
    n_classes=5,
    n_features=3,
    n_informative=3,
    n_redundant=0,
    n_clusters_per_class=1,
    flip_y=0.1
)

ax1 = fig.add_subplot(2, 2, 1, projection='3d')
ax1.scatter(X1[:, 0], X1[:, 1], X1[:, 2], c=Y1, cmap='viridis', edgecolor='none')
ax1.set_title('(S1) 5 cls, 100 ex, 3 dim, conf 0.1')
S1 = [X1, Y1]

# exo 1.1.b.
X2, Y2 = make_classification(
    n_samples=100,
    n_classes=5,
    n_features=3,
    n_informative=3,
    n_redundant=0,
    n_clusters_per_class=1,
    flip_y=0
)

ax2 = fig.add_subplot(2, 2, 2, projection='3d')
ax2.scatter(X2[:, 0], X2[:, 1], X2[:, 2], c=Y2, cmap='viridis', edgecolor='none')
ax2.set_title('(S2) 5 cls, 100 exs, 3 dim, conf 0')
S2 = [X2, Y2]

# exo 1.1.c.
X3, Y3 = make_classification(
    n_samples=100,
    n_classes=5,
    n_features=10,
    n_informative=10,
    n_redundant=0,
    n_clusters_per_class=1,
    flip_y=0.1
)

pca = PCA(n_components=3)
X3_3 = pca.fit_transform(X3)
ax3 = fig.add_subplot(2, 2, 3, projection='3d')
ax3.scatter(X3_3[:, 0], X3_3[:, 1], X3_3[:, 2], c=Y3, cmap='viridis', edgecolor='none')
ax3.set_title('(S3) 5 cls, 100 ex, 10 dim, conf 0.1, PCA')
S3 = [X3, Y3]

# exo 1.1.d.
X4, Y4 = make_classification(
    n_samples=1000,
    n_classes=5,
    n_features=10,
    n_informative=10,
    n_redundant=0,
    n_clusters_per_class=1,
    flip_y=0.1
)

pca = PCA(n_components=3)
X4_3 = pca.fit_transform(X4)
ax4 = fig.add_subplot(2, 2, 4, projection='3d')
ax4.scatter(X4_3[:, 0], X4_3[:, 1], X4_3[:, 2], c=Y4, cmap='viridis', edgecolor='none')
ax4.set_title('(S4) 5 cls, 1000 ex, 10 dim, conf 0.1, PCA')
S4 = [X4, Y4]


# exo 1.1.2 pour etre sur qu'on a de la confusion, on peut prendre n'importe quel classifieur, et on regarde le score
# (si on a un score de 100%, on n'a pas de la confusion) S2, S1, S4, S3

# exo 1.2.1
def learn_one_vs_all(X, Y, Classifier):
    Y_labels = set(Y)
    classes = list(Y_labels)
    Y1 = replace_labels_except(Y, classes[0])
    Y2 = replace_labels_except(Y, classes[1])
    Y3 = replace_labels_except(Y, classes[2])
    Y4 = replace_labels_except(Y, classes[3])
    Y5 = replace_labels_except(Y, classes[4])

    c1 = Classifier()
    c1.fit(X, Y1)

    c2 = Classifier()
    c2.fit(X, Y2)

    c3 = Classifier()
    c3.fit(X, Y3)

    c4 = Classifier()
    c4.fit(X, Y4)

    c5 = Classifier()
    c5.fit(X, Y5)

    return c1, c2, c3, c4, c5


# replace all labels in Y with 0 except label class_1, which is replaced with 1
def replace_labels_except(Y, class_1):
    Y1 = np.zeros(Y.shape)
    for i in range(Y.shape[0]):
        if Y[i] == class_1:
            Y1[i] = 1
        else:
            Y1[i] = 0
    return Y1


def decide_vote(list_pred):
    if sum(list_pred) == 1 or sum(list_pred) == 2:
        return list_pred.index(1)
    else:
        return most_present_class


def vote(clf1, clf2, clf3, clf4, clf5, X_test):
    y_pred1 = clf1.predict(X_test)
    y_pred2 = clf2.predict(X_test)
    y_pred3 = clf3.predict(X_test)
    y_pred4 = clf4.predict(X_test)
    y_pred5 = clf5.predict(X_test)
    y_pred = np.zeros(X_test.shape[0])
    for i in range(X_test.shape[0]):
        list_pred = [y_pred1[i], y_pred2[i], y_pred3[i], y_pred4[i], y_pred5[i]]
        decide_vote(list_pred)
        class_pred = decide_vote(list_pred)
        y_pred[i] = class_pred
    return y_pred


if __name__ == "__main__":
    k = 1
    for S in [S1, S2, S3, S4]:
        # 10 hold-out
        scores = []
        scores_d = []

        cm_scores = []
        cmd_scores = []

        for i in range(10):
            X_train, X_test, y_train, y_test = train_test_split(S[0], S[1], test_size=0.30)

            clf1, clf2, clf3, clf4, clf5 = learn_one_vs_all(X_train, y_train, KNeighborsClassifier)
            clf1_d, clf2_d, clf3_d, clf4_d, clf5_d = learn_one_vs_all(X_train, y_train, DecisionTreeClassifier)

            most_present_class = Counter(y_test).most_common(1)[0][0]

            # evaluate for KNeighborsClassifier
            y_pred = vote(clf1, clf2, clf3, clf4, clf5, X_test)
            nb_clasif_ok = len(numpy.argwhere(y_test == y_pred)[:, 0])
            taux_clasif_ok = nb_clasif_ok / len(y_test)

            # evaluate for DecisionTreeClassifier
            y_pred_d = vote(clf1_d, clf2_d, clf3_d, clf4_d, clf5_d, X_test)
            nb_clasif_ok_d = len(numpy.argwhere(y_test == y_pred_d)[:, 0])
            taux_clasif_ok_d = nb_clasif_ok_d / len(y_test)

            scores.append(taux_clasif_ok)
            scores_d.append(taux_clasif_ok_d)

            c_m = confusion_matrix(y_test, y_pred, normalize='true')
            c_m_d = confusion_matrix(y_test, y_pred_d, normalize='true')

            np.fill_diagonal(c_m, 0)
            np.fill_diagonal(c_m_d, 0)

            cm_scores.append(linalg.norm(c_m, ord=None, axis=None, keepdims=False))
            cmd_scores.append(linalg.norm(c_m_d, ord=None, axis=None, keepdims=False))

        print('OK rate - KNeighborsClassifier for S' + str(k) + " -", sum(scores) / len(scores), ' - ', st.t.interval(alpha=0.95, df=len(scores)-1, loc=np.mean(scores), scale=st.sem(scores)))
        print('OK rate - DecisionTreeClassifier for S' + str(k) + " -", sum(scores_d) / len(scores_d), ' - ', st.t.interval(alpha=0.95, df=len(scores_d)-1, loc=np.mean(scores_d), scale=st.sem(scores_d)))

        print('Norm of CMDwD - KNeighborsClassifier for S' + str(k) + " -",
              sum(cm_scores) / len(cm_scores), ' - ', st.t.interval(alpha=0.95, df=len(cm_scores)-1, loc=np.mean(cm_scores), scale=st.sem(cm_scores)))
        print('Norm of CMDwD - DecisionTreeClassifier for S' + str(k) + " -",
              sum(cmd_scores) / len(cmd_scores), ' - ', st.t.interval(alpha=0.95, df=len(cmd_scores)-1, loc=np.mean(cmd_scores), scale=st.sem(cmd_scores)))

        k = k + 1

    print('--Version multi-classe-')
    scores_k_X4 = []
    scores_d_X4 = []
    scores_k_X4_MCD = []
    scores_d_X4_MCD = []
    for i in range(100, 1001, 100):
        #mean
        scores_k_100 = []
        scores_d_100 = []
        cm_scores_100 = []
        cmd_scores_100 = []
        for j in range(10):
            X, Y = make_classification(
                n_samples=i,
                n_classes=5,
                n_features=10,
                n_informative=10,
                n_redundant=0,
                n_clusters_per_class=1,
                flip_y=0.1
            )
            S = [X, Y]

            X_train, X_test, y_train, y_test = train_test_split(S[0], S[1], test_size=0.30)
            clf_k = KNeighborsClassifier()
            clf_k.fit(X_train, y_train)
            scores_k_100.append(clf_k.score(X_test, y_test))

            clf_d = DecisionTreeClassifier()
            clf_d.fit(X_train, y_train)
            scores_d_100.append(clf_d.score(X_test, y_test))

            c_m = confusion_matrix(y_test, clf_k.predict(X_test), normalize='true')
            c_m_d = confusion_matrix(y_test, clf_d.predict(X_test), normalize='true')

            np.fill_diagonal(c_m, 0)
            np.fill_diagonal(c_m_d, 0)

            cm_scores_100.append(linalg.norm(c_m, ord=None, axis=None, keepdims=False))
            cmd_scores_100.append(linalg.norm(c_m_d, ord=None, axis=None, keepdims=False))

        print('OK rate - KNeighborsClassifier for S4 nb exemples -', i, sum(scores_k_100) / len(scores_k_100), ' - ', st.t.interval(alpha=0.95, df=len(scores_k_100) - 1, loc=np.mean(scores_k_100), scale=st.sem(scores_k_100)))
        print('OK rate - DecisionTreeClassifier for S4 nb exemples -', i, sum(scores_d_100) / len(scores_d_100), ' - ', st.t.interval(alpha=0.95, df=len(scores_d_100) - 1, loc=np.mean(scores_d_100), scale=st.sem(scores_d_100)))
        print('Norm of CMDwD - KNeighborsClassifier for S4 -',
            sum(cm_scores_100) / len(cm_scores_100), ' - ', st.t.interval(alpha=0.95, df=len(cm_scores_100)-1, loc=np.mean(cm_scores_100), scale=st.sem(cm_scores_100)))
        print('Norm of CMDwD - DecisionTreeClassifier for S4 -',
            sum(cmd_scores_100) / len(cmd_scores_100), ' - ', st.t.interval(alpha=0.95, df=len(cmd_scores_100)-1, loc=np.mean(cmd_scores_100), scale=st.sem(cmd_scores_100)))

        scores_k_X4.append(sum(scores_k_100) / len(scores_k_100))
        scores_d_X4.append(sum(scores_d_100) / len(scores_d_100))
        scores_k_X4_MCD.append(sum(cm_scores_100) / len(cm_scores_100))
        scores_d_X4_MCD.append(sum(cmd_scores_100) / len(cmd_scores_100))

    ci_X4 = 1.96 * np.std(scores_k_X4)/np.sqrt(len(scores_k_X4))
    fig2 = plt.figure()
    ax5 = fig2.add_subplot(221)
    ax5.plot([i for i in range(100, 1001, 100)], scores_k_X4)
    ax5.fill_between([i for i in range(100, 1001, 100)], (scores_k_X4-ci_X4), (scores_k_X4+ci_X4), color='b', alpha=.1)
    ax5.set_xlabel('Nombre d\'exemples')
    ax5.set_ylabel('Score')
    ax5.set_title('KNeighborsClassifier - S4 score - nombre d\'exemples')

    ci_d_X4 = 1.96 * np.std(scores_d_X4)/np.sqrt(len(scores_d_X4))
    ax6 = fig2.add_subplot(222)
    ax6.plot([i for i in range(100, 1001, 100)], scores_d_X4)
    ax6.fill_between([i for i in range(100, 1001, 100)], (scores_d_X4-ci_d_X4), (scores_d_X4+ci_d_X4), color='b', alpha=.1)
    ax6.set_xlabel('Nombre d\'exemples')
    ax6.set_ylabel('Score')
    ax6.set_title('DecisionTreeClassifier - S4 score - nombre d\'exemples')

    ci_k_X4_MCD = 1.96 * np.std(scores_k_X4_MCD)/np.sqrt(len(scores_k_X4_MCD))
    ax7 = fig2.add_subplot(223)
    ax7.plot([i for i in range(100, 1001, 100)], scores_k_X4_MCD)
    ax7.fill_between([i for i in range(100, 1001, 100)], (scores_k_X4_MCD-ci_k_X4_MCD), (scores_k_X4_MCD+ci_k_X4_MCD), color='b', alpha=.1)
    ax7.set_xlabel('Nombre d\'exemples')
    ax7.set_ylabel('Score')
    ax7.set_title('KNeighborsClassifier - S4 score CMDwD - nombre d\'exemples')

    ci_d_X4_MCD = 1.96 * np.std(scores_d_X4_MCD)/np.sqrt(len(scores_d_X4_MCD))
    ax8 = fig2.add_subplot(224)
    ax8.plot([i for i in range(100, 1001, 100)], scores_d_X4_MCD)
    ax8.fill_between([i for i in range(100, 1001, 100)], (scores_d_X4_MCD-ci_d_X4_MCD), (scores_d_X4_MCD+ci_d_X4_MCD), color='b', alpha=.1)
    ax8.set_xlabel('Nombre d\'exemples')
    ax8.set_ylabel('Score')
    ax8.set_title('DecisionTreeClassifier - S4 score CMDwD - nombre d\'exemples')

plt.show()
